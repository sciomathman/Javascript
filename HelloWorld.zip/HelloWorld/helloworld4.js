document.getElementById("doc1").innerText = "Hello World";
