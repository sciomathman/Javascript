document.getElementById("doc1").innerHTML = "Hello World";
