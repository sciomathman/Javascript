document.getElementById("doc1").textContent = "Hello World";
