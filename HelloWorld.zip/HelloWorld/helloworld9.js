document.addEventListener('DOMContentLoaded', function(){
    document.body.innerHTML = "Hello World";
});
